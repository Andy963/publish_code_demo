#!usr/bin/env python
# *- coding:utf-8 -*-
# Author: Andy
from flask import render_template, Blueprint


bl = Blueprint('blog', __name__)
import sqlite3
from flask import g

DATABASE_PATH = './db.sqlite3'


def connect_db():
    return sqlite3.connect(DATABASE_PATH)

@bl.before_request
def before_request():
    g.db = connect_db()

@bl.teardown_request
def teardown_request(exception):
    if hasattr(g, 'db'):
        g.db.close()


@bl.route('/home')
def home():
    conn  = connect_db()
    cursor = conn.cursor()

    articles = cursor.execute('Select title,abstract From main.blog_article;')
    context = {'articles': articles, }
    return render_template('blog_home.html', **context)


def detail():
    pass
