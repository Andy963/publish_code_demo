#!usr/bin/env python
# *- coding:utf-8 -*-
# Author: Andy


from flask import Flask
from .views.blog import bl

def create_app():
    app = Flask(__name__, static_folder='static', template_folder='templates')
    app.secret_key = 'flaskexcelproject'
    app.register_blueprint(bl)

    return app


